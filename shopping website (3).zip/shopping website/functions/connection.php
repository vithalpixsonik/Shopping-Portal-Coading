<?php
$host="localhost";
$username="root";
$password="";
$database="Estore";
$con=mysqli_connect($host,$username,$password,$database);
?>