<?php
$host="localhost";
$username="admin";
$password="password";
$database="estore_user";
$con=mysqli_connect($host,$username,$password,$database);
?>